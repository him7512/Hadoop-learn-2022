package cn.itcast.mr.flowsum;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class FlowSumReducer extends Reducer<Text, FlowBean, Text, FlowBean>{
    
    FlowBean v = new FlowBean();
    
    @Override
    protected void reduce(Text key, Iterable<FlowBean> values,
            Reducer<Text, FlowBean, Text, FlowBean>.Context context) throws IOException, InterruptedException {
        
        long upFlowCount =0 ;
        long downFlowCount=0;
        
        for (FlowBean flowBean : values) {
            upFlowCount += flowBean.getUpFlow();
            downFlowCount += flowBean.getDownFlow();
        }
        
        v.set(upFlowCount, downFlowCount);
        
        context.write(key, v);
    }

}
