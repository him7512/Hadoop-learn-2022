package cn.itcast.mr.flowsum;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class FlowSumMapper extends Mapper<LongWritable, Text, Text, FlowBean> {

	// 创建输出k
	Text k = new Text();
	// 创建输出v
	FlowBean v = new FlowBean();

	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, FlowBean>.Context context)
			throws IOException, InterruptedException {

		// 获取读取数据组件返回的每一行内容
		String line = value.toString();

		// 把内容按照\t切割
		String[] fields = line.split("\t");

		// 获取第二个字段 手机号 注意数组是从0开始的
		String phoneNum = fields[1];

		// 获取上行流量 从后获取所需要的字段
		// parseLong方法把String 转成 Long
		Long upFlow = Long.parseLong(fields[fields.length - 3]);

		// 获取下行流量 从后获取所需要的字段
		Long downFlow = Long.parseLong(fields[fields.length - 2]);

		// 输出k设值 手机号
		k.set(phoneNum);
		// 输出v设值 流量对象
		v.set(upFlow, downFlow);
		// <手机号1，bean><手机号2，bean><手机号3，bean>
		context.write(k, v); 
	}

}
