package cn.itcast.mr.flowsum.p;

import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

import cn.itcast.mr.flowsum.FlowBean;

public class ProvincePartitioner extends Partitioner<Text, FlowBean> {
	
	public static HashMap<String, Integer> provinceMap = new HashMap<String, Integer>();
	
	static {
		provinceMap.put("134", 0);//假设代表省份A
		provinceMap.put("135", 1);//假设代表省份B
		provinceMap.put("136", 2);//假设代表省份C
		provinceMap.put("137", 3);//假设代表省份D
		provinceMap.put("138", 4);//假设代表省份E
	}

	//这里就是实际分区方法 返回分区编号，分区编号决定数据存储文件的位置
	@Override
	public int getPartition(Text key, FlowBean value, int numPartitions) {
		Integer code = provinceMap.get(key.toString().substring(0, 3));
		if (code != null) {
			return code;
		}
		return 5;
	}
}
