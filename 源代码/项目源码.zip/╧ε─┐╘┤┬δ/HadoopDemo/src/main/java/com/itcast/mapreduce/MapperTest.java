package com.itcast.mapreduce;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * LongWritable 行偏移量 Text 文本
 * 
 * @author itcast
 *
 */
public class MapperTest extends Mapper<Long, String, String, Integer> {
	
	
	protected void map(Long key, String value, Mapper<Long, String, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		Text keyOut = new Text();
		IntWritable valueOut = new IntWritable();
		String[] arr = value.toString().split(" ");
		for (String s : arr) {
			keyOut.set(s);
			valueOut.set(1);
			context.write(keyOut, valueOut);
		}
	}
}
