package com.itcast.mapreduce;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MRAppTest {
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", "file:///");
		Job job = Job.getInstance(conf);

		// 设置作业属性
		job.setJobName("MRAppTest");
		job.setJarByClass(MRAppTest.class);

		// 设置输入路径
		FileInputFormat.addInputPath(job, new Path("D:/mr/input"));
		// 设置输出路径
		FileOutputFormat.setOutputPath(job, new Path("D:/mr/out"));

		job.setMapperClass(MapperTest.class);
		job.setReducerClass(ReduceTest.class);

		job.setNumReduceTasks(1);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		job.waitForCompletion(false);

	}
}
