/*
Navicat MySQL Data Transfer

Source Server         : hadoop03
Source Server Version : 50173
Source Host           : 192.168.121.134:3306
Source Database       : sqoopdb

Target Server Type    : MYSQL
Target Server Version : 50173
File Encoding         : 65001

Date: 2019-09-27 19:00:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_avgpv_num
-- ----------------------------
DROP TABLE IF EXISTS `t_avgpv_num`;
CREATE TABLE `t_avgpv_num` (
  `dateStr` varchar(255) DEFAULT NULL,
  `avgPvNum` decimal(6,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_avgpv_num
-- ----------------------------
INSERT INTO `t_avgpv_num` VALUES ('2013-09-20', '12.27');
INSERT INTO `t_avgpv_num` VALUES ('2013-09-21', '14.37');
INSERT INTO `t_avgpv_num` VALUES ('2013-09-18', '12.01');
INSERT INTO `t_avgpv_num` VALUES ('2013-09-19', '12.10');
INSERT INTO `t_avgpv_num` VALUES ('2013-09-22', '7.80');
INSERT INTO `t_avgpv_num` VALUES ('2013-09-23', '8.05');
INSERT INTO `t_avgpv_num` VALUES ('2013-09-24', '12.14');
