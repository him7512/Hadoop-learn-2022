package cn.itcast.service;

public interface AvgPvService {

	public String getAvgPvNumByDates(String startDate, String endDate);

}